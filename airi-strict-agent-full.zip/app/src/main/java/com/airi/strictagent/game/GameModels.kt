package com.airi.strictagent.game

import kotlinx.coroutines.flow.Flow

class GameState(
    val width: Int,
    val height: Int,
    val screenshot: ByteArray?,
    val fields: Map<String, String>
)

enum class ActionType { TAP, SWIPE, WAIT }

sealed class GameAction {
    abstract val type: ActionType
    abstract fun describe(): String

    data class Tap(val x: Int, val y: Int) : GameAction() {
        override val type: ActionType = ActionType.TAP
        override fun describe(): String = "TAP ($x, $y)"
    }

    data class Swipe(
        val x1: Int,
        val y1: Int,
        val x2: Int,
        val y2: Int,
        val durationMs: Long
    ) : GameAction() {
        override val type: ActionType = ActionType.SWIPE
        override fun describe(): String = "SWIPE ($x1, $y1) -> ($x2, $y2) trong ${durationMs}ms"
    }

    data class Wait(val durationMs: Long) : GameAction() {
        override val type: ActionType = ActionType.WAIT
        override fun describe(): String = "WAIT ${durationMs}ms"
    }
}

data class GameRules(
    val allowedActions: Set<ActionType>,
    val maxStepsPerPlan: Int,
    val maxWaitMs: Long
) {
    init {
        require(allowedActions.isNotEmpty()) { "allowedActions không được rỗng" }
        require(maxStepsPerPlan > 0) { "maxStepsPerPlan phải > 0" }
        require(maxWaitMs > 0) { "maxWaitMs phải > 0" }
    }
}

data class BridgeAck(val accepted: Boolean, val message: String)

interface GameBridgeTransport {
    val frames: Flow<GameState>
    suspend fun send(action: GameAction): BridgeAck
    fun emergencyHalt()
}
