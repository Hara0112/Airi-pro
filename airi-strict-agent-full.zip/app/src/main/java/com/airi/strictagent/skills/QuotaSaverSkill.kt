package com.airi.strictagent.skills

class QuotaSaverSkill(private val cache: ResponseCache? = null) : SkillInterface {

    override val id: String = "quotasaver"
    override val requiredParams: List<String> = listOf("context", "query", "max_chars")

    override fun assessRisk(command: SkillCommand): RiskLevel = RiskLevel.SAFE

    override suspend fun execute(command: SkillCommand, dryRun: Boolean): SkillResult {
        SkillSupport.missing(command, requiredParams)?.let { return it }
        val context = command.params.getValue("context")
        val query = command.params.getValue("query")
        val maxChars = command.params.getValue("max_chars").trim().toIntOrNull()
        if (maxChars == null || maxChars <= 0) {
            return SkillResult.Failure("max_chars phải là số nguyên dương")
        }

        val key = ResponseCache.keyOf("quotasaver", context, query, maxChars.toString())
        cache?.get(key)?.let { return SkillResult.Success(it) }

        val keywords = QUERY_TOKEN.split(query.lowercase())
            .filter { it.length >= 2 }
            .distinct()
        if (keywords.isEmpty()) {
            return SkillResult.Failure("query không có từ khóa hợp lệ")
        }

        val segments = splitSegments(context, maxChars)
        val scored = segments.mapIndexedNotNull { index, text ->
            val lower = text.lowercase()
            var distinct = 0
            var occurrences = 0
            for (keyword in keywords) {
                val count = countOccurrences(lower, keyword)
                if (count > 0) {
                    distinct++
                    occurrences += count
                }
            }
            if (distinct == 0) null else Scored(index, text, distinct.toLong() * 1000L + occurrences)
        }
        if (scored.isEmpty()) {
            return SkillResult.Failure("Không có đoạn ngữ cảnh nào khớp từ khóa của query")
        }

        val chosen = mutableListOf<Scored>()
        for (candidate in scored.sortedWith(compareByDescending<Scored> { it.score }.thenBy { it.index })) {
            val trial = (chosen + candidate).sortedBy { it.index }
            if (assemble(trial).length <= maxChars) {
                chosen.add(candidate)
            }
        }
        if (chosen.isEmpty()) {
            return SkillResult.Failure("Không đoạn khớp nào vừa trong giới hạn $maxChars ký tự")
        }

        val result = assemble(chosen.sortedBy { it.index })
        cache?.put(key, result)
        return SkillResult.Success(result)
    }

    private class Scored(val index: Int, val text: String, val score: Long)

    private fun splitSegments(context: String, maxChars: Int): List<String> =
        context.replace("\r\n", "\n")
            .split(Regex("\n[ \t]*\n"))
            .map { it.trim('\n') }
            .filter { it.isNotBlank() }
            .flatMap { paragraph ->
                if (paragraph.length <= maxChars) listOf(paragraph)
                else paragraph.split("\n").filter { it.isNotBlank() }
            }

    private fun countOccurrences(text: String, keyword: String): Int {
        var count = 0
        var from = 0
        while (true) {
            val at = text.indexOf(keyword, from)
            if (at < 0) return count
            count++
            from = at + keyword.length
        }
    }

    private fun assemble(sorted: List<Scored>): String {
        val out = StringBuilder()
        sorted.forEachIndexed { i, item ->
            if (i > 0) {
                out.append(if (item.index - sorted[i - 1].index == 1) "\n\n" else "\n\n$GAP_MARKER\n\n")
            }
            out.append(item.text)
        }
        return out.toString()
    }

    private companion object {
        val QUERY_TOKEN = Regex("[^\\p{L}\\p{N}_]+")
        const val GAP_MARKER = "[đã lược bỏ phần không liên quan]"
    }
}
