package com.airi.strictagent.game

import com.airi.strictagent.core.KillSwitch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

sealed class DispatchResult {
    object Sent : DispatchResult()
    object DryRun : DispatchResult()
    data class Rejected(val reason: String) : DispatchResult()
    data class Failed(val reason: String) : DispatchResult()
}

class ActionDispatcher(
    private val transport: GameBridgeTransport,
    private val rateLimiter: RateLimiter,
    private val killSwitch: KillSwitch,
    private val sendTimeoutMs: Long,
    private val onLog: (String) -> Unit
) {
    @Volatile
    private var halted = false

    fun halt() {
        halted = true
        transport.emergencyHalt()
    }

    fun resume() {
        halted = false
    }

    suspend fun dispatch(action: GameAction, dryRun: Boolean): DispatchResult {
        if (dryRun) {
            onLog("[DRY RUN] ${action.describe()}")
            return DispatchResult.DryRun
        }
        if (isStopped()) return DispatchResult.Rejected("Đã dừng khẩn cấp")

        if (action is GameAction.Wait) {
            onLog("[CHỜ] ${action.describe()}")
            delay(action.durationMs)
            return DispatchResult.Sent
        }

        rateLimiter.acquire()
        if (isStopped()) return DispatchResult.Rejected("Đã dừng khẩn cấp")

        return try {
            val ack = withTimeoutOrNull(sendTimeoutMs) { transport.send(action) }
            when {
                ack == null -> DispatchResult.Failed("Hết thời gian chờ game bridge phản hồi")
                !ack.accepted -> DispatchResult.Failed("Game bridge từ chối: ${ack.message}")
                else -> {
                    onLog("[GỬI] ${action.describe()}")
                    DispatchResult.Sent
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            DispatchResult.Failed("Lỗi gửi tới game bridge: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun isStopped(): Boolean = halted || killSwitch.isEngaged
}
