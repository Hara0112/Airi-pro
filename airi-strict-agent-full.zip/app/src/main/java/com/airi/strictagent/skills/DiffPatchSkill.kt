package com.airi.strictagent.skills

import kotlinx.coroutines.CancellationException

class DiffPatchSkill(private val llm: LlmGateway) : SkillInterface {

    override val id: String = "diffpatch"
    override val requiredParams: List<String> =
        listOf("target_file_path", "original_content", "change_request")

    override fun assessRisk(command: SkillCommand): RiskLevel = RiskLevel.MODERATE

    override suspend fun execute(command: SkillCommand, dryRun: Boolean): SkillResult {
        SkillSupport.missing(command, requiredParams)?.let { return it }
        val path = command.params.getValue("target_file_path").trim()
        val original = command.params.getValue("original_content").replace("\r\n", "\n")
        val request = command.params.getValue("change_request").trim()
        if (!SkillSupport.isSafeRelativePath(path)) {
            return SkillResult.Failure("target_file_path phải là đường dẫn tương đối, không chứa '..'")
        }

        val user = buildString {
            appendLine("File: $path")
            appendLine("Yêu cầu thay đổi:")
            appendLine(request)
            appendLine()
            appendLine("Nội dung file gốc:")
            append(original)
        }

        if (dryRun) {
            return SkillResult.Success(
                SkillSupport.dryRunPreview(
                    "DiffPatchSkill",
                    listOf("File: $path", "Yêu cầu: $request", "Số dòng file gốc: ${original.lines().size}"),
                    SYSTEM,
                    user
                )
            )
        }

        val response = try {
            llm.complete(SYSTEM, user)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return SkillResult.Failure("Gọi LLM thất bại: ${e.message ?: e.javaClass.simpleName}")
        }

        SkillSupport.asMissingInfo(response)?.let { return it }
        val blocks = parseBlocks(response)
            ?: return SkillResult.Failure("Phản hồi LLM không đúng định dạng SEARCH/REPLACE")
        return buildPatch(path, original, blocks)
    }

    private class Block(val search: List<String>, val replace: List<String>)

    private class Located(val startLine: Int, val endLine: Int, val replacement: List<String>)

    private fun parseBlocks(response: String): List<Block>? {
        val blocks = mutableListOf<Block>()
        val search = mutableListOf<String>()
        val replace = mutableListOf<String>()
        var state = 0
        for (line in response.replace("\r\n", "\n").split("\n")) {
            val marker = line.trim()
            when (state) {
                0 -> if (marker == SEARCH_MARK) {
                    state = 1
                    search.clear()
                    replace.clear()
                }
                1 -> if (marker == MID_MARK) state = 2 else search.add(line)
                else -> if (marker == END_MARK) {
                    blocks.add(Block(search.toList(), replace.toList()))
                    state = 0
                } else {
                    replace.add(line)
                }
            }
        }
        return if (state != 0 || blocks.isEmpty()) null else blocks
    }

    private fun buildPatch(path: String, original: String, blocks: List<Block>): SkillResult {
        val lines = original.removeSuffix("\n").split("\n")
        val located = mutableListOf<Located>()
        blocks.forEachIndexed { index, block ->
            val label = "Khối SEARCH #${index + 1}"
            if (block.search.isEmpty() || block.search.all { it.isBlank() }) {
                return SkillResult.Failure("$label rỗng, không có điểm neo trong file gốc")
            }
            val matches = findMatches(lines, block.search)
            if (matches.isEmpty()) {
                return SkillResult.Failure("$label không khớp chính xác với file gốc")
            }
            if (matches.size > 1) {
                return SkillResult.Failure("$label khớp ${matches.size} vị trí, không xác định được chỗ cần sửa")
            }
            located.add(Located(matches[0], matches[0] + block.search.size, block.replace))
        }
        located.sortBy { it.startLine }
        for (i in 1 until located.size) {
            if (located[i - 1].endLine > located[i].startLine) {
                return SkillResult.Failure("Hai khối SEARCH chồng lấn nhau trong file gốc")
            }
        }
        if (located.all { lines.subList(it.startLine, it.endLine) == it.replacement }) {
            return SkillResult.Failure("Bản vá không làm thay đổi nội dung file")
        }

        val summary = located.joinToString("; ") { "dòng ${it.startLine + 1}-${it.endLine}" }
        return SkillResult.Success("Vị trí thay đổi trong file gốc: $summary\n\n${buildDiff(path, lines, located)}")
    }

    private fun findMatches(lines: List<String>, search: List<String>): List<Int> {
        val result = mutableListOf<Int>()
        for (start in 0..lines.size - search.size) {
            var same = true
            for (k in search.indices) {
                if (lines[start + k].trimEnd() != search[k].trimEnd()) {
                    same = false
                    break
                }
            }
            if (same) result.add(start)
        }
        return result
    }

    private fun buildDiff(path: String, lines: List<String>, located: List<Located>): String {
        val groups = mutableListOf<MutableList<Located>>()
        for (block in located) {
            val last = groups.lastOrNull()?.last()
            if (last != null && block.startLine - last.endLine <= 2 * CONTEXT) {
                groups.last().add(block)
            } else {
                groups.add(mutableListOf(block))
            }
        }

        val out = StringBuilder("--- a/$path\n+++ b/$path\n")
        var delta = 0
        for (group in groups) {
            val hunkStart = maxOf(0, group.first().startLine - CONTEXT)
            val hunkEnd = minOf(lines.size, group.last().endLine + CONTEXT)
            val body = StringBuilder()
            var oldCount = 0
            var newCount = 0
            var index = hunkStart
            var g = 0
            while (index < hunkEnd) {
                if (g < group.size && index == group[g].startLine) {
                    val block = group[g]
                    for (k in block.startLine until block.endLine) {
                        body.append('-').append(lines[k]).append('\n')
                        oldCount++
                    }
                    for (r in block.replacement) {
                        body.append('+').append(r).append('\n')
                        newCount++
                    }
                    index = block.endLine
                    g++
                } else {
                    body.append(' ').append(lines[index]).append('\n')
                    oldCount++
                    newCount++
                    index++
                }
            }
            val newStart = hunkStart + 1 + delta
            val newStartOut = if (newCount == 0) newStart - 1 else newStart
            out.append("@@ -${hunkStart + 1},$oldCount +$newStartOut,$newCount @@\n").append(body)
            delta += group.sumOf { it.replacement.size - (it.endLine - it.startLine) }
        }
        return out.toString().trimEnd('\n')
    }

    private companion object {
        const val CONTEXT = 3
        const val SEARCH_MARK = "<<<<<<< SEARCH"
        const val MID_MARK = "======="
        const val END_MARK = ">>>>>>> REPLACE"

        val SYSTEM = """
            Bạn là DiffPatchSkill. Xuất bản vá tối thiểu cho file có sẵn dưới dạng các khối SEARCH/REPLACE.
            Định dạng mỗi khối, đúng từng ký tự:
            <<<<<<< SEARCH
            (các dòng nguyên văn từ file gốc)
            =======
            (các dòng thay thế)
            >>>>>>> REPLACE
            Quy tắc bắt buộc:
            1. SEARCH phải sao chép nguyên văn trọn các dòng từ file gốc và chỉ khớp đúng một vị trí.
            2. Chỉ sửa đúng các dòng hoặc hàm liên quan đến yêu cầu, giữ nguyên tên biến, chữ ký hàm và style của phần còn lại.
            3. Không thêm tính năng ngoài yêu cầu, không giải thích, không viết gì ngoài các khối.
            4. Nếu thiếu thông tin bắt buộc, chỉ trả về một dòng bắt đầu bằng [THIẾU THÔNG TIN] và nêu phần thiếu.
        """.trimIndent()
    }
}
