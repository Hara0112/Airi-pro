package com.airi.strictagent.skills

data class SkillField(val key: String, val label: String, val multiline: Boolean = false)

data class SkillCategory(val skillId: String, val title: String, val fields: List<SkillField>)

object SkillCatalog {
    val categories: List<SkillCategory> = listOf(
        SkillCategory(
            skillId = "code",
            title = "Code",
            fields = listOf(
                SkillField("language", "Ngôn ngữ (language)"),
                SkillField("target_file_path", "Đường dẫn file đích (target_file_path)"),
                SkillField("task_description", "Mô tả nhiệm vụ (task_description)", multiline = true)
            )
        ),
        SkillCategory(
            skillId = "image2d",
            title = "Ảnh 2D",
            fields = listOf(
                SkillField("subject", "Chủ thể (subject)"),
                SkillField("resolution", "Độ phân giải (resolution), vd 64x64"),
                SkillField("format", "Định dạng (format): png/webp/svg")
            )
        ),
        SkillCategory(
            skillId = "model3d",
            title = "Model 3D",
            fields = listOf(
                SkillField("subject", "Chủ thể (subject)"),
                SkillField("output_format", "Định dạng xuất (output_format): threejs/gltf/obj"),
                SkillField("scale_unit", "Đơn vị tỉ lệ (scale_unit)")
            )
        ),
        SkillCategory(
            skillId = "game",
            title = "Game",
            fields = listOf(
                SkillField("task_description", "Mô tả lệnh game (task_description)", multiline = true)
            )
        )
    )
}
