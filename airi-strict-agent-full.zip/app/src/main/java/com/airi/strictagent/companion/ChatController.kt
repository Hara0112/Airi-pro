package com.airi.strictagent.companion

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Sender { USER, PERSONA, SYSTEM }

data class ChatMessage(val sender: Sender, val text: String)

class ChatController(private val scope: CoroutineScope) {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _thinking = MutableStateFlow(false)
    val thinking: StateFlow<Boolean> = _thinking.asStateFlow()

    var responder: (suspend (String) -> String)? = null

    private var job: Job? = null

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || _thinking.value) return
        append(Sender.USER, trimmed)
        val active = responder
        if (active == null) {
            append(Sender.SYSTEM, "[THIẾU THÔNG TIN] Chưa có kết nối LLM nên chưa thể trả lời.")
            return
        }
        _thinking.value = true
        job = scope.launch {
            try {
                append(Sender.PERSONA, active(trimmed))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                append(Sender.SYSTEM, "[LỖI] ${e.message ?: e.javaClass.simpleName}")
            } finally {
                _thinking.value = false
            }
        }
    }

    fun cancel() {
        job?.cancel()
        _thinking.value = false
    }

    private fun append(sender: Sender, text: String) {
        _messages.update { it + ChatMessage(sender, text) }
    }
}
