package com.airi.strictagent.skills

internal object SkillSupport {
    const val MISSING_TAG = "[THIẾU THÔNG TIN]"

    private val fence = Regex("```[^\\n]*\\n(.*?)```", RegexOption.DOT_MATCHES_ALL)

    fun missing(command: SkillCommand, required: List<String>): SkillResult.MissingInfo? {
        val absent = required.filter { command.params[it].isNullOrBlank() }
        return if (absent.isEmpty()) null else SkillResult.MissingInfo(absent)
    }

    fun isSafeRelativePath(path: String): Boolean {
        val trimmed = path.trim()
        if (trimmed.isEmpty() || trimmed.startsWith("/") || trimmed.startsWith("\\")) return false
        return trimmed.split('/', '\\').none { it == ".." }
    }

    fun extractCode(response: String): String {
        val inside = fence.find(response)?.groupValues?.get(1) ?: response
        return inside.trim('\n').trimEnd()
    }

    fun asMissingInfo(response: String): SkillResult.MissingInfo? {
        val first = response.trimStart()
        if (!first.startsWith(MISSING_TAG)) return null
        val detail = first.removePrefix(MISSING_TAG).lineSequence().first().trim()
        return SkillResult.MissingInfo(listOf(detail.ifEmpty { "LLM báo thiếu thông tin" }))
    }

    fun dryRunPreview(skillName: String, details: List<String>, system: String, user: String): String =
        buildString {
            appendLine("[DRY RUN] $skillName sẽ gọi LLM (tốn token), chưa gọi.")
            details.forEach { appendLine(it) }
            append("Độ dài prompt dự kiến: ${system.length + user.length} ký tự")
        }
}
