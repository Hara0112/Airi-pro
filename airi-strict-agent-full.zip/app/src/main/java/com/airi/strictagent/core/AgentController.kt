package com.airi.strictagent.core

import com.airi.strictagent.settings.SettingsStore
import com.airi.strictagent.skills.SkillCommand
import com.airi.strictagent.skills.SkillInterface
import com.airi.strictagent.skills.SkillResult
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LogEntry(val time: String, val text: String)

class AgentController(
    private val settings: SettingsStore,
    private val skills: List<SkillInterface>,
    private val gate: ConfirmationGate,
    private val killSwitch: KillSwitch,
    private val scope: CoroutineScope
) {
    private val _log = MutableStateFlow<List<LogEntry>>(emptyList())
    val log: StateFlow<List<LogEntry>> = _log.asStateFlow()

    private val _preview = MutableStateFlow<String?>(null)
    val preview: StateFlow<String?> = _preview.asStateFlow()

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss")

    fun clearLog() {
        _log.value = emptyList()
    }

    fun submit(skillId: String, params: Map<String, String>, dryRunOnly: Boolean) {
        if (_running.value) return
        _running.value = true
        _preview.value = null
        scope.launch {
            try {
                addLog("Nhận lệnh [$skillId], Dry Run: ${if (dryRunOnly) "bật" else "tắt"}")
                val current = settings.settings.value
                if (skillId !in current.enabledSkills) {
                    addLog("[CHẶN] Skill '$skillId' đang tắt trong Cài đặt")
                    return@launch
                }
                val router = GuardrailRouterCore(
                    skills.filter { it.id in current.enabledSkills },
                    settings.forbiddenRules(),
                    gate,
                    killSwitch
                ) { addLog(it) }
                val command = SkillCommand(skillId, params, params.values.joinToString("\n"))
                handle(router.route(command, dryRunOnly))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                addLog("[LỖI] ${e.message ?: e.javaClass.simpleName}")
            } finally {
                _running.value = false
            }
        }
    }

    private fun handle(decision: RouteDecision) {
        when (decision) {
            is RouteDecision.Blocked -> addLog("[CHẶN] ${decision.reason}")
            is RouteDecision.NeedInfo ->
                addLog("[THIẾU THÔNG TIN] ${decision.missing.joinToString()}")
            is RouteDecision.Declined ->
                addLog("[TỪ CHỐI] Người dùng không xác nhận (${decision.risk.name})")
            is RouteDecision.Completed -> when (val result = decision.result) {
                is SkillResult.Success -> {
                    _preview.value = result.output
                    addLog("[HOÀN TẤT] Rủi ro ${decision.risk.name}")
                }
                is SkillResult.MissingInfo ->
                    addLog("[THIẾU THÔNG TIN] ${result.fields.joinToString()}")
                is SkillResult.Failure -> addLog("[LỖI] ${result.reason}")
            }
        }
    }

    private fun addLog(text: String) {
        val entry = LogEntry(LocalTime.now().format(timeFormat), text)
        _log.update { (it + entry).takeLast(MAX_LOG) }
    }

    private companion object {
        const val MAX_LOG = 200
    }
}
