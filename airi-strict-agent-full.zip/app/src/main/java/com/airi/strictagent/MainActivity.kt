package com.airi.strictagent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.airi.strictagent.companion.CompanionPersonaManager
import com.airi.strictagent.companion.InteractionMode
import com.airi.strictagent.core.ConfirmationGate
import com.airi.strictagent.core.KillSwitch

class MainActivity : ComponentActivity() {

    private val killSwitch = KillSwitch()
    private val gate = ConfirmationGate()
    private val persona by lazy {
        CompanionPersonaManager(getSharedPreferences("persona", MODE_PRIVATE))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Screen()
            }
        }
    }

    @Composable
    private fun Screen() {
        val profile by persona.profile.collectAsState()
        val mode by persona.mode.collectAsState()
        val killed by killSwitch.engaged.collectAsState()
        val pending by gate.pending.collectAsState()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Text(text = profile.name, style = MaterialTheme.typography.headlineMedium)
            Text(
                text = if (mode == InteractionMode.CHAT) "Chế độ: Trò chuyện" else "Chế độ: Làm việc nghiêm túc"
            )
            Spacer(Modifier.height(16.dp))
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    persona.setMode(
                        if (mode == InteractionMode.CHAT) InteractionMode.WORK else InteractionMode.CHAT
                    )
                }
            ) {
                Text("Chuyển chế độ")
            }
            Spacer(Modifier.height(16.dp))
            Button(
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                onClick = {
                    if (killed) {
                        killSwitch.reset()
                    } else {
                        killSwitch.trigger()
                        gate.cancelAll()
                    }
                }
            ) {
                Text(if (killed) "Đã dừng khẩn cấp - Bấm để mở lại" else "DỪNG KHẨN CẤP")
            }
        }

        pending?.let { request ->
            AlertDialog(
                onDismissRequest = { gate.respond(false) },
                title = { Text("Xác nhận (${request.risk.name}): ${request.skillId}") },
                text = { Text(request.dryRunPreview) },
                confirmButton = { TextButton(onClick = { gate.respond(true) }) { Text("Xác nhận") } },
                dismissButton = { TextButton(onClick = { gate.respond(false) }) { Text("Hủy") } }
            )
        }
    }
}
