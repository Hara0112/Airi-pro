package com.airi.strictagent.skills

import kotlinx.coroutines.CancellationException

class Image2DSkill(private val llm: LlmGateway) : SkillInterface {

    override val id: String = "image2d"
    override val requiredParams: List<String> = listOf("subject", "resolution", "format")

    override fun assessRisk(command: SkillCommand): RiskLevel = RiskLevel.MODERATE

    override suspend fun execute(command: SkillCommand, dryRun: Boolean): SkillResult {
        SkillSupport.missing(command, requiredParams)?.let { return it }
        val subject = command.params.getValue("subject").trim()
        val resolution = command.params.getValue("resolution").trim().lowercase()
        val format = command.params.getValue("format").trim().lowercase()

        val size = SIZE.matchEntire(resolution)
        val width = size?.groupValues?.get(1)?.toIntOrNull()
        val height = size?.groupValues?.get(2)?.toIntOrNull()
        if (width == null || height == null || width <= 0 || height <= 0) {
            return SkillResult.Failure("resolution phải có dạng WxH với số nguyên dương, ví dụ 64x64")
        }
        if (format !in FORMATS) {
            return SkillResult.Failure("format phải là một trong: ${FORMATS.joinToString("/")}")
        }

        val gridRaw = command.params["grid"]?.trim()?.lowercase().orEmpty()
        if (gridRaw.isNotEmpty()) {
            val grid = SIZE.matchEntire(gridRaw)
            val cols = grid?.groupValues?.get(1)?.toIntOrNull()
            val rows = grid?.groupValues?.get(2)?.toIntOrNull()
            if (cols == null || rows == null || cols <= 0 || rows <= 0) {
                return SkillResult.Failure("grid phải có dạng CxR với số nguyên dương, ví dụ 4x4")
            }
            if (width % cols != 0 || height % rows != 0) {
                return SkillResult.Failure("Kích thước ${width}x$height không chia hết cho lưới ${cols}x$rows")
            }
        }

        val background = command.params["background"]?.trim().orEmpty()
        val palette = command.params["palette"]?.trim().orEmpty()
        val output = if (format == "svg") {
            "một file SVG hợp lệ có width=\"$width\", height=\"$height\" và viewBox=\"0 0 $width $height\""
        } else {
            "một file HTML5 duy nhất, vẽ bằng canvas đúng ${width}x$height pixel và xuất file $format bằng canvas.toBlob"
        }

        val user = buildString {
            appendLine("Chủ thể: $subject")
            appendLine("Kích thước: ${width}x$height pixel")
            appendLine("Định dạng: $format")
            if (gridRaw.isNotEmpty()) appendLine("Lưới khung hình (cột x hàng): $gridRaw")
            if (background.isNotEmpty()) appendLine("Nền: $background")
            if (palette.isNotEmpty()) appendLine("Bảng màu: $palette")
            append("Đầu ra: $output")
        }

        if (dryRun) {
            return SkillResult.Success(
                SkillSupport.dryRunPreview(
                    "Image2DSkill",
                    listOf("Chủ thể: $subject", "Kích thước: ${width}x$height", "Định dạng: $format", "Đầu ra: $output"),
                    SYSTEM,
                    user
                )
            )
        }

        return try {
            val response = llm.complete(SYSTEM, user)
            SkillSupport.asMissingInfo(response)
                ?: SkillResult.Success(SkillSupport.extractCode(response))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SkillResult.Failure("Gọi LLM thất bại: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private companion object {
        val SIZE = Regex("^(\\d+)x(\\d+)$")
        val FORMATS = setOf("png", "webp", "svg")

        val SYSTEM = """
            Bạn là Image2DSkill. Sinh mã tạo ảnh 2D (ảnh, sprite sheet, texture hoặc UI asset) theo đúng thông số.
            Quy tắc bắt buộc:
            1. Xuất đúng kích thước pixel và đúng số khung hình (lưới) được yêu cầu.
            2. Giữ nền trong suốt (alpha) nếu là sprite hoặc texture nhân vật, vật phẩm, trừ khi yêu cầu nêu nền khác.
            3. Không tự ý đổi bảng màu hoặc thêm chi tiết ngoài mô tả chủ thể.
            4. Không thêm tính năng, giao diện hay chú thích thừa.
            5. Nếu thiếu thông tin bắt buộc, chỉ trả về một dòng bắt đầu bằng [THIẾU THÔNG TIN] và nêu phần thiếu.
            6. Chỉ trả về nội dung file trong đúng một khối ``` duy nhất, không giải thích.
        """.trimIndent()
    }
}
