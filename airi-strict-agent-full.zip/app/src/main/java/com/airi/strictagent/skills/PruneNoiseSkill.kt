package com.airi.strictagent.skills

class PruneNoiseSkill : SkillInterface {

    override val id: String = "prunenoise"
    override val requiredParams: List<String> = listOf("text", "keep")

    override fun assessRisk(command: SkillCommand): RiskLevel = RiskLevel.SAFE

    override suspend fun execute(command: SkillCommand, dryRun: Boolean): SkillResult {
        SkillSupport.missing(command, requiredParams)?.let { return it }
        val text = command.params.getValue("text").replace("\r\n", "\n")
        return when (val keep = command.params.getValue("keep").trim().lowercase()) {
            "code_only" -> keepCodeOnly(text)
            "unique" -> SkillResult.Success(keepUnique(text))
            else -> SkillResult.Failure("keep phải là 'code_only' hoặc 'unique', nhận được '$keep'")
        }
    }

    private fun keepCodeOnly(text: String): SkillResult {
        val blocks = FENCE.findAll(text).map { it.groupValues[1].trim('\n').trimEnd() }.toList()
        if (blocks.isEmpty()) {
            return SkillResult.Failure("Không có khối code (```) nào trong text")
        }
        return SkillResult.Success(blocks.joinToString("\n\n"))
    }

    private fun keepUnique(text: String): String {
        val seen = HashSet<String>()
        val kept = mutableListOf<String>()
        for (unit in splitUnits(text)) {
            val key = if (unit.startsWith("```")) unit else unit.split(WHITESPACE).joinToString(" ")
            if (seen.add(key)) kept.add(unit)
        }
        return kept.joinToString("\n\n")
    }

    private fun splitUnits(text: String): List<String> {
        val units = mutableListOf<String>()
        val current = mutableListOf<String>()
        var inFence = false

        fun flush() {
            if (current.isNotEmpty()) {
                units.add(current.joinToString("\n"))
                current.clear()
            }
        }

        for (raw in text.split("\n")) {
            val isFenceLine = raw.trimStart().startsWith("```")
            when {
                isFenceLine && !inFence -> {
                    flush()
                    current.add(raw.trimEnd())
                    inFence = true
                }
                isFenceLine -> {
                    current.add(raw.trimEnd())
                    inFence = false
                    flush()
                }
                inFence -> current.add(raw)
                raw.isBlank() -> flush()
                else -> current.add(raw.trimEnd())
            }
        }
        flush()
        return units
    }

    private companion object {
        val FENCE = Regex("```[^\\n]*\\n(.*?)```", RegexOption.DOT_MATCHES_ALL)
        val WHITESPACE = Regex("\\s+")
    }
}
