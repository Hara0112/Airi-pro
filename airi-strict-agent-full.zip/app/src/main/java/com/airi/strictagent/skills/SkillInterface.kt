package com.airi.strictagent.skills

enum class RiskLevel { SAFE, MODERATE, HIGH }

data class SkillCommand(
    val skillId: String,
    val params: Map<String, String>,
    val rawText: String
)

sealed class SkillResult {
    data class Success(val output: String) : SkillResult()
    data class MissingInfo(val fields: List<String>) : SkillResult()
    data class Failure(val reason: String) : SkillResult()
}

interface SkillInterface {
    val id: String
    val requiredParams: List<String>
    fun assessRisk(command: SkillCommand): RiskLevel
    suspend fun execute(command: SkillCommand, dryRun: Boolean): SkillResult
}
