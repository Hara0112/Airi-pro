package com.airi.strictagent.game

import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class RateLimiter(
    val maxActions: Int,
    val windowMs: Long,
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000L }
) {
    init {
        require(maxActions > 0) { "maxActions phải > 0" }
        require(windowMs > 0) { "windowMs phải > 0" }
    }

    private val mutex = Mutex()
    private val stamps = ArrayDeque<Long>()

    suspend fun acquire() {
        while (true) {
            val waitMs = mutex.withLock {
                val now = nowMs()
                while (stamps.isNotEmpty() && now - stamps.first() >= windowMs) {
                    stamps.removeFirst()
                }
                if (stamps.size < maxActions) {
                    stamps.addLast(now)
                    0L
                } else {
                    stamps.first() + windowMs - now
                }
            }
            if (waitMs <= 0L) return
            delay(waitMs)
        }
    }
}
