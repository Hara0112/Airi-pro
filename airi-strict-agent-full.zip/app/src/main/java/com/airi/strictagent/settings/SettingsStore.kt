package com.airi.strictagent.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.airi.strictagent.core.ForbiddenRule
import com.airi.strictagent.skills.SkillCatalog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class ForbiddenRuleSpec(val id: String, val pattern: String, val reason: String)

data class AppSettings(
    val apiKey: String = "",
    val baseUrl: String = "",
    val modelName: String = "",
    val bridgeUrl: String = "",
    val enabledSkills: Set<String> = SkillCatalog.categories.map { it.skillId }.toSet(),
    val forbiddenRules: List<ForbiddenRuleSpec> = emptyList()
)

class SettingsStore(context: Context) {

    private val plain: SharedPreferences =
        context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val secure: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "secure_settings",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun save(value: AppSettings) {
        secure.edit().putString(KEY_API_KEY, value.apiKey).apply()
        val rules = JSONArray()
        value.forbiddenRules.forEach {
            rules.put(
                JSONObject()
                    .put("id", it.id)
                    .put("pattern", it.pattern)
                    .put("reason", it.reason)
            )
        }
        plain.edit()
            .putString(KEY_BASE_URL, value.baseUrl)
            .putString(KEY_MODEL, value.modelName)
            .putString(KEY_BRIDGE_URL, value.bridgeUrl)
            .putStringSet(KEY_SKILLS, value.enabledSkills.toSet())
            .putString(KEY_RULES, rules.toString())
            .apply()
        _settings.value = value
    }

    fun forbiddenRules(): List<ForbiddenRule> =
        _settings.value.forbiddenRules.mapNotNull { spec ->
            runCatching { ForbiddenRule(spec.id, Regex(spec.pattern), spec.reason) }.getOrNull()
        }

    private fun load(): AppSettings {
        val defaults = AppSettings()
        val rules = mutableListOf<ForbiddenRuleSpec>()
        runCatching {
            val array = JSONArray(plain.getString(KEY_RULES, "[]") ?: "[]")
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                rules.add(ForbiddenRuleSpec(o.getString("id"), o.getString("pattern"), o.getString("reason")))
            }
        }
        return AppSettings(
            apiKey = secure.getString(KEY_API_KEY, "") ?: "",
            baseUrl = plain.getString(KEY_BASE_URL, "") ?: "",
            modelName = plain.getString(KEY_MODEL, "") ?: "",
            bridgeUrl = plain.getString(KEY_BRIDGE_URL, "") ?: "",
            enabledSkills = plain.getStringSet(KEY_SKILLS, null)?.toSet() ?: defaults.enabledSkills,
            forbiddenRules = rules
        )
    }

    private companion object {
        const val KEY_API_KEY = "api_key"
        const val KEY_BASE_URL = "base_url"
        const val KEY_MODEL = "model_name"
        const val KEY_BRIDGE_URL = "bridge_url"
        const val KEY_SKILLS = "enabled_skills"
        const val KEY_RULES = "forbidden_rules"
    }
}
