package com.airi.strictagent.core

import com.airi.strictagent.skills.RiskLevel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class ConfirmationRequest(
    val skillId: String,
    val risk: RiskLevel,
    val dryRunPreview: String
)

class ConfirmationGate {
    private val mutex = Mutex()
    private val _pending = MutableStateFlow<ConfirmationRequest?>(null)
    val pending: StateFlow<ConfirmationRequest?> = _pending.asStateFlow()
    @Volatile
    private var answer: CompletableDeferred<Boolean>? = null

    suspend fun request(request: ConfirmationRequest): Boolean = mutex.withLock {
        val deferred = CompletableDeferred<Boolean>()
        answer = deferred
        _pending.value = request
        try {
            deferred.await()
        } finally {
            _pending.value = null
            answer = null
        }
    }

    fun respond(approved: Boolean) {
        answer?.complete(approved)
    }

    fun cancelAll() {
        answer?.complete(false)
    }
}
