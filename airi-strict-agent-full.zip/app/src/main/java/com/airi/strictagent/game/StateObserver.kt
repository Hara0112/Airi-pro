package com.airi.strictagent.game

import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withTimeoutOrNull

class StateObserver(private val transport: GameBridgeTransport) {

    suspend fun observe(timeoutMs: Long): GameState? =
        withTimeoutOrNull(timeoutMs) {
            transport.frames.firstOrNull { it.width > 0 && it.height > 0 }
        }
}
