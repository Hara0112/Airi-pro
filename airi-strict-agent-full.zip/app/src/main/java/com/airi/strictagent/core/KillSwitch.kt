package com.airi.strictagent.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class KillSwitch {
    private val _engaged = MutableStateFlow(false)
    val engaged: StateFlow<Boolean> = _engaged.asStateFlow()
    val isEngaged: Boolean get() = _engaged.value

    fun trigger() {
        _engaged.value = true
    }

    fun reset() {
        _engaged.value = false
    }
}
