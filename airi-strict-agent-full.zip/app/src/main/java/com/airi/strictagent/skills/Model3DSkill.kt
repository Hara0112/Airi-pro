package com.airi.strictagent.skills

import kotlinx.coroutines.CancellationException

class Model3DSkill(private val llm: LlmGateway) : SkillInterface {

    override val id: String = "model3d"
    override val requiredParams: List<String> = listOf("subject", "output_format", "scale_unit")

    override fun assessRisk(command: SkillCommand): RiskLevel = RiskLevel.MODERATE

    override suspend fun execute(command: SkillCommand, dryRun: Boolean): SkillResult {
        SkillSupport.missing(command, requiredParams)?.let { return it }
        val subject = command.params.getValue("subject").trim()
        val format = command.params.getValue("output_format").trim().lowercase()
        val unit = command.params.getValue("scale_unit").trim()
        if (format !in FORMATS) {
            return SkillResult.Failure("output_format phải là một trong: ${FORMATS.joinToString(" | ")}")
        }

        val pivot = command.params["pivot"]?.trim().orEmpty().ifEmpty { "tâm đáy" }
        val parts = command.params["parts"]?.trim().orEmpty()
        val dimensions = command.params["dimensions"]?.trim().orEmpty()

        val output = if (format == "threejs") {
            "một module JavaScript xuất hàm createModel() trả về THREE.Group, không có scene, camera, ánh sáng hay renderer"
        } else {
            "một script Python dùng trimesh, xuất file .$format"
        }

        val user = buildString {
            appendLine("Chủ thể: $subject")
            appendLine("Định dạng xuất: $format")
            appendLine("Đơn vị tỉ lệ: $unit")
            appendLine("Gốc tọa độ (pivot): $pivot")
            if (parts.isNotEmpty()) appendLine("Các bộ phận: $parts")
            if (dimensions.isNotEmpty()) appendLine("Kích thước: $dimensions")
            append("Đầu ra: $output")
        }

        if (dryRun) {
            return SkillResult.Success(
                SkillSupport.dryRunPreview(
                    "Model3DSkill",
                    listOf("Chủ thể: $subject", "Định dạng: $format", "Đơn vị: $unit", "Pivot: $pivot", "Đầu ra: $output"),
                    SYSTEM,
                    user
                )
            )
        }

        return try {
            val response = llm.complete(SYSTEM, user)
            SkillSupport.asMissingInfo(response)
                ?: SkillResult.Success(SkillSupport.extractCode(response))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SkillResult.Failure("Gọi LLM thất bại: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private companion object {
        val FORMATS = setOf("threejs", "gltf", "obj")

        val SYSTEM = """
            Bạn là Model3DSkill. Tạo mã dựng model 3D procedural theo đúng thông số.
            Quy tắc bắt buộc:
            1. Đặt gốc tọa độ (pivot) chính xác theo yêu cầu, mặc định là tâm đáy.
            2. Tách nhóm mesh hoặc bone rõ ràng, đặt tên theo bộ phận, không gộp thành một khối.
            3. Không thêm ánh sáng, skybox hay môi trường thừa.
            4. Chỉ dùng API có thật của Three.js, trimesh và numpy, không dùng API đã bị khai tử hay tự chế.
            5. Dùng đúng đơn vị tỉ lệ được yêu cầu và ghi rõ trong comment đầu file.
            6. Nếu thiếu thông tin bắt buộc hoặc không chắc một API có tồn tại, chỉ trả về một dòng bắt đầu bằng [THIẾU THÔNG TIN] và nêu phần thiếu.
            7. Chỉ trả về nội dung file trong đúng một khối ``` duy nhất, không giải thích.
        """.trimIndent()
    }
}
