package com.airi.strictagent.game

enum class StopReason {
    GOAL_REACHED,
    MAX_ITERATIONS,
    MAX_DURATION,
    NO_MORE_ACTIONS,
    OBSERVE_TIMEOUT,
    PLAN_CONFLICT,
    DISPATCH_FAILED,
    DECLINED,
    DRY_RUN_COMPLETE,
    KILL_SWITCH,
    CANCELLED,
    INTERNAL_ERROR
}

data class StopConditions(
    val maxIterations: Int,
    val maxDurationMs: Long,
    val goalReached: ((GameState) -> Boolean)? = null
) {
    init {
        require(maxIterations > 0) { "maxIterations phải > 0" }
        require(maxDurationMs > 0) { "maxDurationMs phải > 0" }
    }

    fun evaluate(state: GameState, completedIterations: Int, elapsedMs: Long): StopReason? = when {
        goalReached?.invoke(state) == true -> StopReason.GOAL_REACHED
        completedIterations >= maxIterations -> StopReason.MAX_ITERATIONS
        elapsedMs >= maxDurationMs -> StopReason.MAX_DURATION
        else -> null
    }
}
