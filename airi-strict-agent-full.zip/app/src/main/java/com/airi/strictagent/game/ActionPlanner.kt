package com.airi.strictagent.game

interface PlanStrategy {
    suspend fun propose(command: String, state: GameState, rules: GameRules): List<GameAction>
}

sealed class PlanResult {
    data class Valid(val steps: List<GameAction>) : PlanResult()
    object Empty : PlanResult()
    data class Conflict(val issues: List<String>) : PlanResult()
}

class ActionPlanner(
    private val strategy: PlanStrategy,
    private val rules: GameRules
) {

    suspend fun plan(command: String, state: GameState): PlanResult {
        if (command.isBlank()) {
            return PlanResult.Conflict(listOf("Lệnh người dùng trống"))
        }
        val steps = strategy.propose(command, state, rules)
        if (steps.isEmpty()) {
            return PlanResult.Empty
        }
        val issues = validate(steps, state)
        return if (issues.isEmpty()) PlanResult.Valid(steps) else PlanResult.Conflict(issues)
    }

    private fun validate(steps: List<GameAction>, state: GameState): List<String> {
        val issues = mutableListOf<String>()
        if (steps.size > rules.maxStepsPerPlan) {
            issues.add("Kế hoạch có ${steps.size} bước, vượt giới hạn ${rules.maxStepsPerPlan}")
        }
        steps.forEachIndexed { index, step ->
            val label = "Bước ${index + 1} (${step.describe()})"
            if (step.type !in rules.allowedActions) {
                issues.add("$label: loại thao tác ${step.type} không được luật cho phép")
            }
            when (step) {
                is GameAction.Tap -> {
                    if (!inBounds(step.x, step.y, state)) {
                        issues.add("$label: tọa độ ngoài màn hình ${state.width}x${state.height}")
                    }
                }
                is GameAction.Swipe -> {
                    if (!inBounds(step.x1, step.y1, state) || !inBounds(step.x2, step.y2, state)) {
                        issues.add("$label: tọa độ ngoài màn hình ${state.width}x${state.height}")
                    }
                    if (step.x1 == step.x2 && step.y1 == step.y2) {
                        issues.add("$label: điểm đầu trùng điểm cuối")
                    }
                    if (step.durationMs <= 0) {
                        issues.add("$label: thời lượng vuốt phải > 0")
                    }
                }
                is GameAction.Wait -> {
                    if (step.durationMs <= 0 || step.durationMs > rules.maxWaitMs) {
                        issues.add("$label: thời gian chờ phải trong (0, ${rules.maxWaitMs}]ms")
                    }
                }
            }
        }
        return issues
    }

    private fun inBounds(x: Int, y: Int, state: GameState): Boolean =
        x in 0 until state.width && y in 0 until state.height
}
