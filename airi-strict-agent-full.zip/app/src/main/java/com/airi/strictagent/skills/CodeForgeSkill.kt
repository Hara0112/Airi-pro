package com.airi.strictagent.skills

import kotlinx.coroutines.CancellationException

class CodeForgeSkill(private val llm: LlmGateway) : SkillInterface {

    override val id: String = "code"
    override val requiredParams: List<String> = listOf("language", "target_file_path", "task_description")

    override fun assessRisk(command: SkillCommand): RiskLevel = RiskLevel.MODERATE

    override suspend fun execute(command: SkillCommand, dryRun: Boolean): SkillResult {
        SkillSupport.missing(command, requiredParams)?.let { return it }
        val language = command.params.getValue("language").trim()
        val path = command.params.getValue("target_file_path").trim()
        val task = command.params.getValue("task_description").trim()
        if (!SkillSupport.isSafeRelativePath(path)) {
            return SkillResult.Failure("target_file_path phải là đường dẫn tương đối, không chứa '..'")
        }

        val user = buildString {
            appendLine("Ngôn ngữ: $language")
            appendLine("File đích: $path")
            appendLine("Nhiệm vụ:")
            append(task)
        }

        if (dryRun) {
            return SkillResult.Success(
                SkillSupport.dryRunPreview(
                    "CodeForgeSkill",
                    listOf("File đích: $path", "Ngôn ngữ: $language", "Nhiệm vụ: $task"),
                    SYSTEM,
                    user
                )
            )
        }

        return try {
            val response = llm.complete(SYSTEM, user)
            SkillSupport.asMissingInfo(response)
                ?: SkillResult.Success(SkillSupport.extractCode(response))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SkillResult.Failure("Gọi LLM thất bại: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private companion object {
        val SYSTEM = """
            Bạn là CodeForgeSkill. Viết mã nguồn hoàn chỉnh cho đúng một file theo yêu cầu.
            Quy tắc bắt buộc:
            1. Code phải biên dịch hoặc chạy được, đủ import, không dùng API đã bị khai tử hoặc tự chế.
            2. Không viết placeholder (TODO, "...", lược bỏ logic).
            3. Không thêm dependency, tính năng hay file ngoài yêu cầu.
            4. Giữ nguyên tên class, package và chữ ký hàm nếu yêu cầu đã nêu.
            5. Nếu thiếu thông tin bắt buộc để viết đúng, chỉ trả về một dòng bắt đầu bằng [THIẾU THÔNG TIN] và nêu phần thiếu.
            6. Chỉ trả về nội dung file trong đúng một khối ``` duy nhất, không giải thích.
        """.trimIndent()
    }
}
