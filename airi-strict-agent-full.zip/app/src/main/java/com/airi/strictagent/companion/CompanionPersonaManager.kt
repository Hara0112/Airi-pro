package com.airi.strictagent.companion

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class InteractionMode { CHAT, WORK }

enum class Emotion { NEUTRAL, HAPPY, SAD, ANGRY, SURPRISED }

data class PersonaProfile(val name: String, val personality: String)

class CompanionPersonaManager(private val prefs: SharedPreferences) {

    private val _profile = MutableStateFlow(loadProfile())
    val profile: StateFlow<PersonaProfile> = _profile.asStateFlow()

    private val _mode = MutableStateFlow(loadMode())
    val mode: StateFlow<InteractionMode> = _mode.asStateFlow()

    private val _emotion = MutableStateFlow(Emotion.NEUTRAL)
    val emotion: StateFlow<Emotion> = _emotion.asStateFlow()

    fun updateProfile(name: String, personality: String) {
        val updated = PersonaProfile(name.trim(), personality.trim())
        prefs.edit()
            .putString(KEY_NAME, updated.name)
            .putString(KEY_PERSONALITY, updated.personality)
            .apply()
        _profile.value = updated
    }

    fun setMode(mode: InteractionMode) {
        prefs.edit().putString(KEY_MODE, mode.name).apply()
        _mode.value = mode
    }

    fun setEmotion(emotion: Emotion) {
        _emotion.value = emotion
    }

    fun buildSystemPrompt(): String {
        val p = _profile.value
        return when (_mode.value) {
            InteractionMode.CHAT ->
                "Bạn là ${p.name}. Tính cách: ${p.personality}. " +
                    "Cảm xúc hiện tại: ${_emotion.value.name}. " +
                    "Trò chuyện nhập vai tự nhiên bằng tiếng Việt."
            InteractionMode.WORK ->
                "Chế độ làm việc nghiêm túc, không nhập vai. " +
                    "Chỉ làm đúng yêu cầu, không thêm bớt ngoài phạm vi. " +
                    "Không bịa đặt API, tên hàm, thư viện hay đường dẫn. " +
                    "Thiếu thông tin bắt buộc thì gắn [THIẾU THÔNG TIN] và hỏi ngắn gọn."
        }
    }

    private fun loadProfile(): PersonaProfile = PersonaProfile(
        name = prefs.getString(KEY_NAME, null) ?: DEFAULT_NAME,
        personality = prefs.getString(KEY_PERSONALITY, null) ?: DEFAULT_PERSONALITY
    )

    private fun loadMode(): InteractionMode {
        val saved = prefs.getString(KEY_MODE, null) ?: return InteractionMode.CHAT
        return InteractionMode.values().firstOrNull { it.name == saved } ?: InteractionMode.CHAT
    }

    private companion object {
        const val KEY_NAME = "persona_name"
        const val KEY_PERSONALITY = "persona_personality"
        const val KEY_MODE = "persona_mode"
        const val DEFAULT_NAME = "AIRI"
        const val DEFAULT_PERSONALITY = "Thân thiện, trung tính, lịch sự."
    }
}
