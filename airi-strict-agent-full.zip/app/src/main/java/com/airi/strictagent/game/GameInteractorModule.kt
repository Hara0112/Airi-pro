package com.airi.strictagent.game

import com.airi.strictagent.core.ConfirmationGate
import com.airi.strictagent.core.ConfirmationRequest
import com.airi.strictagent.core.KillSwitch
import com.airi.strictagent.skills.RiskLevel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class InteractorStatus {
    object Idle : InteractorStatus()
    object Running : InteractorStatus()
    data class Stopped(val reason: StopReason, val detail: String) : InteractorStatus()
}

class GameInteractorModule(
    private val observer: StateObserver,
    private val planner: ActionPlanner,
    private val dispatcher: ActionDispatcher,
    private val rateLimiter: RateLimiter,
    private val stopConditions: StopConditions,
    private val observeTimeoutMs: Long,
    private val gate: ConfirmationGate,
    private val killSwitch: KillSwitch,
    private val scope: CoroutineScope,
    private val onLog: (String) -> Unit
) {
    private val _status = MutableStateFlow<InteractorStatus>(InteractorStatus.Idle)
    val status: StateFlow<InteractorStatus> = _status.asStateFlow()

    @Volatile
    private var loopJob: Job? = null

    init {
        scope.launch {
            killSwitch.engaged.collect { engaged ->
                if (engaged) emergencyStop()
            }
        }
    }

    fun start(command: String, dryRun: Boolean): Boolean {
        if (loopJob?.isActive == true) {
            onLog("[TỪ CHỐI] Vòng lặp game đang chạy")
            return false
        }
        if (killSwitch.isEngaged) {
            onLog("[TỪ CHỐI] Kill Switch đang bật")
            return false
        }
        dispatcher.resume()
        _status.value = InteractorStatus.Running
        onLog("[BẮT ĐẦU] Dry Run: ${if (dryRun) "bật" else "tắt"}")
        loopJob = scope.launch { runLoop(command, dryRun) }
        return true
    }

    fun emergencyStop() {
        dispatcher.halt()
        gate.cancelAll()
        loopJob?.cancel()
        if (_status.value is InteractorStatus.Running) {
            _status.value = InteractorStatus.Stopped(StopReason.KILL_SWITCH, "Dừng khẩn cấp")
            onLog("[KILL SWITCH] Đã ngắt toàn bộ vòng lặp game")
        }
    }

    private suspend fun runLoop(command: String, dryRun: Boolean) {
        val startMs = nowMs()
        var completedIterations = 0
        var confirmed = dryRun
        try {
            while (true) {
                currentCoroutineContext().ensureActive()

                val state = observer.observe(observeTimeoutMs)
                    ?: return finish(StopReason.OBSERVE_TIMEOUT, "Không nhận được trạng thái game trong ${observeTimeoutMs}ms")

                val stop = stopConditions.evaluate(state, completedIterations, nowMs() - startMs)
                if (stop != null) return finish(stop, "Thỏa điều kiện dừng")

                val steps = when (val plan = planner.plan(command, state)) {
                    is PlanResult.Empty -> return finish(StopReason.NO_MORE_ACTIONS, "Không còn thao tác nào cần làm")
                    is PlanResult.Conflict -> return finish(StopReason.PLAN_CONFLICT, plan.issues.joinToString("; "))
                    is PlanResult.Valid -> plan.steps
                }

                if (!confirmed) {
                    val approved = gate.request(
                        ConfirmationRequest("game", RiskLevel.HIGH, buildPreview(command, steps))
                    )
                    if (!approved) return finish(StopReason.DECLINED, "Người dùng không xác nhận")
                    if (killSwitch.isEngaged) return finish(StopReason.KILL_SWITCH, "Kill Switch đang bật")
                    confirmed = true
                }

                for (step in steps) {
                    currentCoroutineContext().ensureActive()
                    when (val result = dispatcher.dispatch(step, dryRun)) {
                        is DispatchResult.Failed -> return finish(StopReason.DISPATCH_FAILED, result.reason)
                        is DispatchResult.Rejected -> return finish(StopReason.KILL_SWITCH, result.reason)
                        DispatchResult.Sent, DispatchResult.DryRun -> Unit
                    }
                }

                completedIterations++
                if (dryRun) return finish(StopReason.DRY_RUN_COMPLETE, "Đã in kế hoạch dự kiến, không thao tác thật")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            finish(StopReason.INTERNAL_ERROR, e.message ?: e.javaClass.simpleName)
        } finally {
            if (_status.value is InteractorStatus.Running) {
                _status.value = InteractorStatus.Stopped(StopReason.CANCELLED, "Vòng lặp bị hủy")
            }
        }
    }

    private fun finish(reason: StopReason, detail: String) {
        _status.value = InteractorStatus.Stopped(reason, detail)
        onLog("[DỪNG] ${reason.name}: $detail")
    }

    private fun buildPreview(command: String, steps: List<GameAction>): String = buildString {
        appendLine("Lệnh: $command")
        appendLine("Tốc độ tối đa: ${rateLimiter.maxActions} thao tác / ${rateLimiter.windowMs}ms")
        appendLine("Dừng sau tối đa ${stopConditions.maxIterations} vòng hoặc ${stopConditions.maxDurationMs}ms")
        appendLine("Kế hoạch đầu tiên:")
        steps.forEachIndexed { i, step -> appendLine("${i + 1}. ${step.describe()}") }
    }

    private fun nowMs(): Long = System.nanoTime() / 1_000_000L
}
