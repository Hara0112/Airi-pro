package com.airi.strictagent.core

import com.airi.strictagent.skills.RiskLevel
import com.airi.strictagent.skills.SkillCommand
import com.airi.strictagent.skills.SkillInterface
import com.airi.strictagent.skills.SkillResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class ForbiddenRule(
    val id: String,
    val pattern: Regex,
    val reason: String
)

sealed class RouteDecision {
    data class Blocked(val reason: String) : RouteDecision()
    data class NeedInfo(val missing: List<String>) : RouteDecision()
    data class Declined(val risk: RiskLevel) : RouteDecision()
    data class Completed(val risk: RiskLevel, val result: SkillResult) : RouteDecision()
}

class GuardrailRouterCore(
    skills: List<SkillInterface>,
    private val forbiddenRules: List<ForbiddenRule>,
    private val gate: ConfirmationGate,
    private val killSwitch: KillSwitch,
    private val onStep: (String) -> Unit = {}
) {
    private val skillMap: Map<String, SkillInterface> = skills.associateBy { it.id }

    suspend fun route(command: SkillCommand, dryRunOnly: Boolean = false): RouteDecision {
        onStep("Kiểm tra Kill Switch")
        if (killSwitch.isEngaged) {
            return RouteDecision.Blocked("Kill Switch đang bật")
        }

        onStep("Kiểm tra điều cấm (${forbiddenRules.size} quy tắc)")
        val violated = forbiddenRules.firstOrNull { it.pattern.containsMatchIn(command.rawText) }
        if (violated != null) {
            return RouteDecision.Blocked("Vi phạm điều cấm [${violated.id}]: ${violated.reason}")
        }

        onStep("Tìm skill '${command.skillId}'")
        val skill = skillMap[command.skillId]
            ?: return RouteDecision.Blocked("Không có skill '${command.skillId}'")

        onStep("Kiểm tra tham số bắt buộc: ${skill.requiredParams.joinToString()}")
        val missing = skill.requiredParams.filter { command.params[it].isNullOrBlank() }
        if (missing.isNotEmpty()) {
            return RouteDecision.NeedInfo(missing)
        }

        val risk = skill.assessRisk(command)
        onStep("Đánh giá rủi ro: ${risk.name}")

        if (dryRunOnly) {
            onStep("Dry Run: chỉ xem trước, không thực thi")
            return RouteDecision.Completed(risk, skill.execute(command, dryRun = true))
        }

        if (risk == RiskLevel.SAFE) {
            onStep("Thực thi skill")
            return RouteDecision.Completed(risk, executeGuarded(skill, command))
        }

        onStep("Chạy Dry Run để xem trước")
        val preview = skill.execute(command, dryRun = true)
        if (preview !is SkillResult.Success) {
            return RouteDecision.Completed(risk, preview)
        }

        onStep("Chờ người dùng xác nhận")
        val approved = gate.request(ConfirmationRequest(command.skillId, risk, preview.output))
        if (!approved) {
            return RouteDecision.Declined(risk)
        }
        if (killSwitch.isEngaged) {
            return RouteDecision.Blocked("Kill Switch đang bật")
        }
        onStep("Đã xác nhận, thực thi skill")
        return RouteDecision.Completed(risk, executeGuarded(skill, command))
    }

    private suspend fun executeGuarded(skill: SkillInterface, command: SkillCommand): SkillResult =
        coroutineScope {
            val work = async { skill.execute(command, dryRun = false) }
            val watcher = launch {
                killSwitch.engaged.first { it }
                work.cancel()
            }
            try {
                work.await()
            } catch (e: CancellationException) {
                if (killSwitch.isEngaged) SkillResult.Failure("Đã dừng bởi Kill Switch") else throw e
            } finally {
                watcher.cancel()
            }
        }
}
