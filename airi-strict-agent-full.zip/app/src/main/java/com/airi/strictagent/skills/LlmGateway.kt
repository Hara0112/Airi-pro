package com.airi.strictagent.skills

import java.security.MessageDigest

interface LlmGateway {
    suspend fun complete(systemPrompt: String, userPrompt: String): String
}

class ResponseCache(private val maxEntries: Int) {
    init {
        require(maxEntries > 0) { "maxEntries phải > 0" }
    }

    private val map = object : LinkedHashMap<String, String>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean =
            size > maxEntries
    }

    fun get(key: String): String? = synchronized(map) { map[key] }

    fun put(key: String, value: String) {
        synchronized(map) { map[key] = value }
    }

    companion object {
        fun keyOf(vararg parts: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(parts.joinToString("\u0000").toByteArray(Charsets.UTF_8))
            return digest.joinToString("") { "%02x".format(it) }
        }
    }
}

class CachedLlmGateway(
    private val delegate: LlmGateway,
    private val cache: ResponseCache
) : LlmGateway {

    override suspend fun complete(systemPrompt: String, userPrompt: String): String {
        val key = ResponseCache.keyOf("llm", systemPrompt, userPrompt)
        cache.get(key)?.let { return it }
        val response = delegate.complete(systemPrompt, userPrompt)
        if (response.isNotBlank()) {
            cache.put(key, response)
        }
        return response
    }
}
